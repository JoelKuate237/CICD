const request = require('supertest');
const app = require('../src/index');

describe('Tests API', () => {
  test('GET / devrait retourner le message de bienvenue', async () => {
    const res = await request(app).get('/');
    expect(res.statusCode).toBe(200);
    expect(res.body.message).toBe("Bienvenue sur l'API TP1 CI/CD");
  });

  test('GET /health devrait retourner status ok', async () => {
    const res = await request(app).get('/health');
    expect(res.statusCode).toBe(200);
    expect(res.body.status).toBe('ok');
    expect(res.body).toHaveProperty('timestamp');
  });

  test('GET /add/2/3 devrait retourner 5', async () => {
    const res = await request(app).get('/add/2/3');
    expect(res.statusCode).toBe(200);
    expect(res.body.result).toBe(5);
  });
  
  test('GET /add/a/3 devrait retourner une erreur 400', async () => {
    const res = await request(app).get('/add/a/3');
    expect(res.statusCode).toBe(400);
    expect(res.body.error).toBe('Parametres invalides');
  });
});
