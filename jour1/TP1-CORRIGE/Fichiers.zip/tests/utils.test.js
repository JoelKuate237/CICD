const { add, multiply, isEven } = require('../src/utils');

describe('Fonctions utilitaires', () => {
  test('add(2, 3) devrait retourner 5', () => {
    expect(add(2, 3)).toBe(5);
  });
  test('multiply(2, 3) devrait retourner 6', () => {
    expect(multiply(2, 3)).toBe(6);
  });
  test('isEven(4) devrait retourner true', () => {
    expect(isEven(4)).toBe(true);
  });
});
